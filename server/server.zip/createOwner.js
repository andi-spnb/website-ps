// server/createOwner.js
require('./src/scripts/createOwnerUser');